$(document).ready(function() {
    $('#ocupaciones').change(function() {
        recargarLista();
    });
});

function recargarLista() {
    $.ajax({
        type: "POST",
        url: "../controlador/getOcupaciones.php",
        data: "idOcupacion="+ $('#ocupaciones').val(),
        

        success: function(r) {

            $('#ocupaciones').html(r);
        }

    });
}