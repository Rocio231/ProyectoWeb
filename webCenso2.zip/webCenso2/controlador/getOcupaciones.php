<?php

require_once "../modelo/CRUD.php";


$ocupacion = $_POST['idocupacion'];

$CRUD = new CRUD();
$local = $CRUD->seleccionarOcupacion();


$cadena='<option value='.$cw['nombre_ocupacion'].'>'.$cw['nombre_ocupacion'];
foreach($local as $cw){

    
}

echo $cadena."</option";